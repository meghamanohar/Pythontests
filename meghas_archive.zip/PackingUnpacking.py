x = ("Guru99", 20, "Education")    # tuple packing
(company, emp, profile) = x    # tuple unpacking
print(company)
print(emp)
print(profile)

a=(5,6)
b=(6,4)
if (a>b):print("a is bigger")
else: print("b is bigger")

a = {'x':100, 'y':200}
b = list(a.items())
print(b)