def main():
    print("Hello World!")
print(__name__)
print("My first main function")

